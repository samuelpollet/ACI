# APIC Login

https://{{apic}}/api/aaaLogin.json

``` json
{
  "aaaUser":{
    "attributes":{
      "name":"{{username}}",
      "pwd":"{{password}}"
    }
  }
}
```
